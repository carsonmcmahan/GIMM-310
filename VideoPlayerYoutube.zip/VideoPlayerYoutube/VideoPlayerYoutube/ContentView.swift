//
//  ContentView.swift
//  VideoPlayerYoutube
//
//  Created by Carson McMahan on 2/8/24.
//

import SwiftUI

struct ContentView: View {
    var videos: [Video] = VideoList.topTwo
    
    var body: some View {
        NavigationView {
            List(videos) {video in
                NavigationLink(destination: VideoDetailView(video: video)) {
                    VideoCell(video: video)
                }
            }
            .navigationTitle("GIMM Works")
        }
    }
}

struct VideoCell: View {
    var video: Video
    var body: some View {
        HStack {
            Image(video.imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 80)
                .clipShape(RoundedRectangle(cornerRadius: 4))
                .padding(.vertical, 4)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(video.title)
                    .fontWeight(.semibold)
                    .lineLimit(2)
                    .minimumScaleFactor(0.5)
                    
                Text(video.uploadDate)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

#Preview {
    ContentView()
}
