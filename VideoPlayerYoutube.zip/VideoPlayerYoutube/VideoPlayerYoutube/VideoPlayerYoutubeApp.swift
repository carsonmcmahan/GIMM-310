//
//  VideoPlayerYoutubeApp.swift
//  VideoPlayerYoutube
//
//  Created by Carson McMahan on 2/8/24.
//

import SwiftUI

@main
struct VideoPlayerYoutubeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
