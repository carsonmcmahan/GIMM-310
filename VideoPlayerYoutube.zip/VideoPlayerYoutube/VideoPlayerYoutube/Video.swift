//
//  Video.swift
//  VideoPlayerYoutube
//
//  Created by Carson McMahan on 2/8/24.
//

import SwiftUI

struct Video: Identifiable {
    let id = UUID()
    let imageName: String
    let title: String
    let description: String
    let viewCount: Int
    let uploadDate: String
    let url: URL
}

struct VideoList {
    static let topTwo = [
        Video(imageName: "Dev League 2021",
            title: "DevLeague 2021",
            description: "Meet our GIMm developers that will be working with you Gear Up Idaho's Dev Lerague!",
            viewCount: 70,
            uploadDate: "Oct 10, 2021",
            url: URL(string: "https://www.youtube.com/watch?v=t1IgELSbB48")!),
        
        Video(imageName: "GIMM Life Season 2",
              title: "Welcome to GIMM",
              description: "Join us for the first episode of the second season of GIMM Life",
              viewCount: 173,
              uploadDate: "April 19, 2023",
              url: URL(string: "https://www.youtube.com/watch?v=YDUUXKYtT_E")!),
    ]
}
