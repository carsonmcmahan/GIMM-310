//
//  Week_Three_SwiftUI_TutorialApp.swift
//  Week Three SwiftUI Tutorial
//
//  Created by Carson McMahan on 1/22/24.
//

import SwiftUI

@main
struct Week_Three_SwiftUI_TutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
