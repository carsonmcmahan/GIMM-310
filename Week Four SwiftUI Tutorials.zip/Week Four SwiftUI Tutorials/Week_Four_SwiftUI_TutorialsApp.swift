//
//  Week_Four_SwiftUI_TutorialsApp.swift
//  Week Four SwiftUI Tutorials
//
//  Created by Carson McMahan on 1/27/24.
//

import SwiftUI

@main
struct Week_Four_SwiftUI_TutorialsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
